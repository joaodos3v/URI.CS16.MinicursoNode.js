let dinamico;
console.log(dinamico, typeof dinamico);
dinamico = 'sou uma string';
console.log(dinamico, typeof dinamico);
dinamico = 5;
console.log(dinamico, typeof dinamico);
dinamico = ['array', 'de', 'strings']
console.log(dinamico, typeof dinamico, Array.isArray(dinamico));
dinamico = {
    objeto: true
}
console.log(dinamico, typeof dinamico);